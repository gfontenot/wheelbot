Partial Class ACCS_Sample_Search
    Inherits System.Web.UI.Page

End Class