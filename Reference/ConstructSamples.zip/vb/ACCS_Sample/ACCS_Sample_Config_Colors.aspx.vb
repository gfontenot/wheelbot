Partial Class ACCS_Sample_Config_Colors
    Inherits System.Web.UI.Page

    Sub Page_Load(ByVal Sender As System.Object, ByVal e As System.EventArgs)

    End Sub
end class