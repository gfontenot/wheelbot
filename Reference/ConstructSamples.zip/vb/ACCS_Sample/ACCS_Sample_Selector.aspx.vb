Partial Class ACCS_Sample_Selector
    Inherits System.Web.UI.Page

End Class